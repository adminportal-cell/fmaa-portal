---
name: FMAA Portal setup
description: Key facts about this project restored from an uploaded archive — architecture decisions, auth, admin access, and known type quirks.
---

## Architecture
- pnpm monorepo: `artifacts/portal` (React+Vite+Clerk), `artifacts/api-server` (Express 5), `lib/api-zod`, `lib/api-client-react`, `lib/db` (Drizzle/PostgreSQL)
- API spec in `lib/api-spec/openapi.yaml` is the source of truth; run `pnpm --filter @workspace/api-spec run codegen` after every spec change.

## Auth
- Clerk (Replit-managed) is set up. `CLERK_SECRET_KEY`, `CLERK_PUBLISHABLE_KEY`, `VITE_CLERK_PUBLISHABLE_KEY` are provisioned.
- Server uses `publishableKeyFromHost(getClerkProxyHost(req), process.env.CLERK_PUBLISHABLE_KEY)` in `app.ts` — do not change this pattern.

## Admin access
- `adminportal@fmaa.com.au` and `bridget.davis@fmaa.com.au` are hardcoded in `PRE_AUTHORIZED_ADMINS` in `artifacts/api-server/src/middlewares/requireAuth.ts`. They get `role: "admin"` JIT on any API call — no DB change needed, just sign in once.

**Why:** Admin emails were hardcoded to bootstrap before the DB admin flow was built.

## Resource creation bug fix
- Both `onError` handlers in `resource-form-dialog.tsx` were `() => toast(...)` (discarding the error). Fixed to `(err: Error) => toast({ ..., description: err.message, variant: "destructive" })`.
- Same fix applied to `alumni-form-dialog.tsx` and all delete-mutation `onError` handlers in resources, alumni, and technicals pages.

**Why:** `ApiError` extends `Error` and `buildErrorMessage()` in `custom-fetch.ts` extracts the server's `error` field from JSON. `err.message` reliably shows the actual HTTP error.

## TypeScript quirk — Express 5 params
- Express 5 types `req.params.*` as `string | string[]`. Use `req.params["id"] as string` (not `req.params.id`) to satisfy TS when not going through Zod safeParse. Only one route had this issue: `POST /resources/:id/view`.

## Archive import quirk
- `cp -r source/ dest/` when dest exists merges INTO dest and, if source was copied without trailing slash, nests a `src/src/` inside `src/`. Fix: use `cp -r source/. dest/` (with dot) or delete the nesting manually.
